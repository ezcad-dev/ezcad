# -*- coding: utf-8 -*-

""" Entry point to the application """

from ezcad.app.main import main
main()
