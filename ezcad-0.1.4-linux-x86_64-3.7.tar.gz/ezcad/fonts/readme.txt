
1) flaticon.com, search, download SVG file.
   If cannot find desired icon online, go to step 2.
2) Adobe Illustrator, design your own icon, export to SVG file.
3) fontastic.me, import your SVG file, customize, download.
4) Extract the ttf file, prepare the character mapping json file.
5) ezcad/utils/icon_manager.py load and use.

http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=iws-chapter08

http://rafaltomal.com/how-to-create-and-use-your-own-icon-fonts/

https://goinggnu.wordpress.com/2014/06/26/how-to-get-character-map-of-a-ttf-font/


These two files are probably download from QtAwesome:
  https://github.com/spyder-ide/qtawesome/tree/master/qtawesome/fonts
    fontawesome-webfont-4.7.0.ttf
    fontawesome-webfont-4.7.0-charmap.json
The QtAwesome repo seems built upon the FontAwesome repo:
  https://github.com/FortAwesome/Font-Awesome/
  https://fontawesome.com/


Follow this page to upgrade use fontawesome 5.x
https://github.com/spyder-ide/qtawesome
