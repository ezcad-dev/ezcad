For GUI language support
