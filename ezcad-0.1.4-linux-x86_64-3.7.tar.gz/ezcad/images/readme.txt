The app icon and splash files are downloaded from https://www.flaticon.com

Can open the svg file with vim and edit the xml content (fill for color).
